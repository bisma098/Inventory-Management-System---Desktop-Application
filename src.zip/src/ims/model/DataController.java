package ims.model;

public class DataController {
    
}
